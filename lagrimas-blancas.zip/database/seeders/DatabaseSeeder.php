<?php

namespace Database\Seeders;

use App\Models\Announcement;
use App\Models\Campaign;
use App\Models\User;
use App\Models\Volunteer;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Administrador por defecto (CAMBIAR la contraseña en producción)
        $admin = User::updateOrCreate(
            ['email' => 'admin@lagrimasblancas.org'],
            ['name' => 'Administrador ONG', 'password' => Hash::make('Admin12345!'), 'role' => User::ROLE_ADMIN]
        );

        User::updateOrCreate(
            ['email' => 'visitante@example.com'],
            ['name' => 'Visitante Demo', 'password' => Hash::make('Visitante123'), 'role' => User::ROLE_PUBLIC]
        );

        $campaigns = [
            ['Canastas de alimentos para familias vulnerables', 'Entrega mensual de canastas básicas a familias de los asentamientos humanos de Cerro Colorado y Cayma, priorizando niños y adultos mayores.', 15000, 9800, 'active'],
            ['Útiles escolares 2026', 'Kits escolares completos para 300 niños de zonas rurales de Arequipa, con cuadernos, mochilas y material de dibujo.', 8000, 8000, 'completed'],
            ['Abrigo contra las heladas', 'Frazadas, chompas y calefacción segura para comunidades altoandinas durante la temporada de heladas.', 12000, 4300, 'active'],
            ['Atención médica itinerante', 'Campañas de salud gratuitas con médicos voluntarios en distritos alejados.', 20000, 2500, 'active'],
        ];
        foreach ($campaigns as [$title, $desc, $goal, $current, $status]) {
            Campaign::create([
                'title' => $title, 'description' => $desc, 'goal_amount' => $goal,
                'current_amount' => $current, 'status' => $status,
                'image_url' => null,
            ]);
        }

        $news = [
            ['Entregamos 200 canastas en Cerro Colorado', 'Gracias a donantes y voluntarios logramos entregar 200 canastas de alimentos a familias que más lo necesitan este mes.', 'Noticia'],
            ['Feria solidaria en la Plaza de Armas', 'Te invitamos a nuestra feria solidaria con música, comida y artesanías. Todo lo recaudado se destinará a la campaña de abrigo.', 'Evento'],
            ['Urgente: se necesitan frazadas', 'Las heladas se intensifican en zonas altoandinas. Necesitamos frazadas y ropa de abrigo; recibimos donaciones en nuestra sede.', 'Urgente'],
            ['Nuevo convenio con la Universidad', 'Firmamos un convenio para que estudiantes realicen su servicio social en nuestros proyectos.', 'Noticia'],
            ['Jornada de salud gratuita', 'Este sábado atenderemos medicina general y pediatría de manera gratuita. Cupos limitados, inscríbete con anticipación.', 'Evento'],
            ['Rendición de cuentas del trimestre', 'Publicamos el informe de ingresos y gastos del trimestre, disponible en la sección de transparencia.', 'Noticia'],
        ];
        foreach ($news as $i => [$title, $content, $cat]) {
            Announcement::create([
                'title' => $title, 'content' => $content, 'category' => $cat,
                'published_at' => now()->subDays($i * 3), 'user_id' => $admin->id,
            ]);
        }

        $volunteers = [
            ['María Quispe Huamaní', 'maria.quispe@example.com', '987654321', 'Fines de semana', 'Enfermería, primeros auxilios', 'approved'],
            ['Luis Cáceres Rojas', 'luis.caceres@example.com', '954321876', 'Tardes de lunes a viernes', 'Logística, conducción de vehículos', 'pending'],
            ['Ana Valdivia Mamani', 'ana.valdivia@example.com', '912345678', 'Sábados por la mañana', 'Diseño gráfico y redes sociales', 'pending'],
            ['Jorge Salas Pinto', 'jorge.salas@example.com', '976543210', 'Domingos', 'Cocina para grupos grandes', 'rejected'],
            ['Rosa Linares Condori', 'rosa.linares@example.com', '965432187', 'Flexible', 'Docencia, apoyo escolar', 'approved'],
            ['Diego Paredes Ccori', 'diego.paredes@example.com', '945612378', 'Noches entre semana', 'Contabilidad y rendición de cuentas', 'pending'],
        ];
        foreach ($volunteers as [$name, $email, $phone, $avail, $skills, $status]) {
            $v = new Volunteer(['full_name' => $name, 'email' => $email, 'phone' => $phone, 'availability' => $avail, 'skills' => $skills]);
            $v->status = $status;
            $v->save();
        }
    }
}
