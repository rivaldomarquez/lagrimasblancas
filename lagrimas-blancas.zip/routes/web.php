<?php

use App\Http\Controllers\Admin;
use App\Http\Controllers\AnnouncementController;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\CampaignController;
use App\Http\Controllers\DonationController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\VolunteerController;
use Illuminate\Support\Facades\Route;

/* ----------------------- Rutas públicas ----------------------- */
Route::get('/', [HomeController::class, 'index'])->name('home');

Route::get('/campanas', [CampaignController::class, 'index'])->name('campaigns.index');
Route::get('/campanas/{campaign}', [CampaignController::class, 'show'])->name('campaigns.show');

Route::get('/noticias', [AnnouncementController::class, 'index'])->name('announcements.index');
Route::get('/noticias/{announcement}', [AnnouncementController::class, 'show'])->name('announcements.show');

Route::get('/voluntariado', [VolunteerController::class, 'create'])->name('volunteers.create');
Route::post('/voluntariado', [VolunteerController::class, 'store'])
    ->middleware('throttle:5,1') // anti-spam: 5 envíos por minuto
    ->name('volunteers.store');

Route::get('/transparencia', [DonationController::class, 'index'])->name('donations');

/* ----------------------- Autenticación ----------------------- */
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:6,1');
    Route::get('/registro', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/registro', [AuthController::class, 'register'])->middleware('throttle:6,1');
});
Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');

/* ----------------------- Panel administrativo ----------------------- */
Route::prefix('admin')->name('admin.')->middleware(['auth', 'admin'])->group(function () {
    Route::get('/', [Admin\DashboardController::class, 'index'])->name('dashboard');

    Route::resource('campaigns', Admin\CampaignController::class)->except('show');
    Route::patch('campaigns/{campaign}/status', [Admin\CampaignController::class, 'toggleStatus'])
        ->name('campaigns.status');

    Route::resource('announcements', Admin\AnnouncementController::class)->except('show');

    Route::get('volunteers', [Admin\VolunteerController::class, 'index'])->name('volunteers.index');
    Route::patch('volunteers/{volunteer}/status', [Admin\VolunteerController::class, 'updateStatus'])
        ->name('volunteers.status');
    Route::delete('volunteers/{volunteer}', [Admin\VolunteerController::class, 'destroy'])
        ->name('volunteers.destroy');
});
