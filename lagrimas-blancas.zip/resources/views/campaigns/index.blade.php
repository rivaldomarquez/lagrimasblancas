@extends('layouts.app')
@section('title', 'Campañas')

@section('content')
<div class="container py-4">
    <h1 class="section-title">Campañas</h1>
    <div class="row g-4 mt-1">
        @forelse($campaigns as $campaign)
            <div class="col-12 col-md-6 col-lg-4">@include('partials.campaign-card')</div>
        @empty
            <p class="text-secondary">No hay campañas publicadas todavía.</p>
        @endforelse
    </div>
    <div class="mt-4">{{ $campaigns->links() }}</div>
</div>
@endsection
