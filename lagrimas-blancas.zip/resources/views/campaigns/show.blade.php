@extends('layouts.app')
@section('title', $campaign->title)

@section('content')
<div class="container py-4" style="max-width: 860px">
    <a href="{{ route('campaigns.index') }}" class="small">&larr; Todas las campañas</a>
    <h1 class="mt-2">{{ $campaign->title }}</h1>
    @if($campaign->image_url)
        <img class="img-fluid rounded my-3" src="{{ $campaign->image_url }}" alt="{{ $campaign->title }}">
    @endif
    <div class="progress my-3" role="progressbar" aria-valuenow="{{ $campaign->progress }}" aria-valuemin="0" aria-valuemax="100">
        <div class="progress-bar {{ $campaign->status === 'completed' ? 'done' : '' }}" style="width: {{ $campaign->progress }}%"></div>
    </div>
    <p><strong>S/ {{ number_format($campaign->current_amount, 2) }}</strong> recaudados de S/ {{ number_format($campaign->goal_amount, 2) }} ({{ $campaign->progress }}%)</p>
    <p class="pre-wrap">{{ $campaign->description }}</p>
    @if($campaign->status === 'active')
        <a href="{{ route('donations') }}" class="btn btn-cta">Donar a esta campaña</a>
    @else
        <span class="badge text-bg-secondary">Campaña completada, ¡gracias por tu apoyo!</span>
    @endif
</div>
@endsection
