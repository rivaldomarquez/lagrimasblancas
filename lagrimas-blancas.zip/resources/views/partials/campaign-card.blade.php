<div class="card-lb d-flex flex-column">
    @if($campaign->image_url)
        <img class="thumb" src="{{ $campaign->image_url }}" alt="{{ $campaign->title }}" loading="lazy">
    @else
        <div class="thumb-empty"><span class="drop"></span></div>
    @endif
    <div class="p-3 d-flex flex-column flex-grow-1">
        <h3 class="h5">{{ $campaign->title }}</h3>
        <p class="text-secondary small">{{ \Illuminate\Support\Str::limit($campaign->description, 110) }}</p>
        <div class="mt-auto">
            <div class="progress mb-2" role="progressbar" aria-label="Avance de la campaña" aria-valuenow="{{ $campaign->progress }}" aria-valuemin="0" aria-valuemax="100">
                <div class="progress-bar {{ $campaign->status === 'completed' ? 'done' : '' }}" style="width: {{ $campaign->progress }}%"></div>
            </div>
            <div class="d-flex justify-content-between small mb-3">
                <span>S/ {{ number_format($campaign->current_amount, 2) }} de S/ {{ number_format($campaign->goal_amount, 2) }}</span>
                <strong>{{ $campaign->progress }}%</strong>
            </div>
            <a href="{{ route('campaigns.show', $campaign) }}" class="btn btn-outline-primary btn-sm">Ver campaña</a>
            @if($campaign->status === 'completed')<span class="badge text-bg-secondary ms-1">Completada</span>@endif
        </div>
    </div>
</div>
