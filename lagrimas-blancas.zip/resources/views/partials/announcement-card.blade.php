<div class="card-lb p-3 d-flex flex-column">
    <div class="mb-2">
        <span class="badge badge-cat {{ $announcement->category === 'Urgente' ? 'urgent' : '' }}">{{ $announcement->category }}</span>
        <span class="small text-secondary ms-2">{{ optional($announcement->published_at)->translatedFormat('d \d\e F, Y') }}</span>
    </div>
    <h3 class="h5">{{ $announcement->title }}</h3>
    <p class="text-secondary small">{{ \Illuminate\Support\Str::limit($announcement->content, 120) }}</p>
    <a class="mt-auto small fw-bold" href="{{ route('announcements.show', $announcement) }}">Leer completo</a>
</div>
