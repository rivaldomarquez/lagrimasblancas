@extends('layouts.app')
@section('title', 'Inicio')

@section('content')
<section class="hero py-5 mt-3">
    <div class="container py-lg-4">
        <h1>Cada gota cuenta: acompañamos a las familias de Arequipa</h1>
        <p class="lead my-3">Somos una ONG que reúne donaciones y voluntarios para llevar alimento, abrigo, educación y salud a quienes más lo necesitan.</p>
        <div class="d-flex flex-wrap gap-2">
            <a href="{{ route('donations') }}" class="btn btn-cta btn-lg">Quiero donar</a>
            <a href="{{ route('volunteers.create') }}" class="btn btn-outline-primary btn-lg">Ser voluntario</a>
        </div>
    </div>
</section>

<section class="container mt-5">
    <div class="d-flex justify-content-between align-items-end mb-3">
        <h2 class="section-title mb-0">Campañas activas</h2>
        <a href="{{ route('campaigns.index') }}">Ver todas</a>
    </div>
    <div class="row g-4">
        @forelse($campaigns as $campaign)
            <div class="col-12 col-md-6 col-lg-4">@include('partials.campaign-card')</div>
        @empty
            <p class="text-secondary">Pronto publicaremos nuevas campañas.</p>
        @endforelse
    </div>
</section>

<section class="container mt-5">
    <div class="d-flex justify-content-between align-items-end mb-3">
        <h2 class="section-title mb-0">Últimos comunicados</h2>
        <a href="{{ route('announcements.index') }}">Ver todos</a>
    </div>
    <div class="row g-4">
        @forelse($announcements as $announcement)
            <div class="col-12 col-md-6 col-lg-4">@include('partials.announcement-card')</div>
        @empty
            <p class="text-secondary">Aún no hay comunicados.</p>
        @endforelse
    </div>
</section>
@endsection
