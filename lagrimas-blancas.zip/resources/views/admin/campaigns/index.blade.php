@extends('layouts.app')
@section('title', 'Campañas (admin)')

@section('content')
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1 class="section-title mb-0">Campañas</h1>
        <a href="{{ route('admin.campaigns.create') }}" class="btn btn-cta">Nueva campaña</a>
    </div>
    <div class="table-responsive">
        <table class="table table-hover">
            <thead><tr><th>Título</th><th>Avance</th><th>Estado</th><th class="text-end">Acciones</th></tr></thead>
            <tbody>
            @forelse($campaigns as $campaign)
                <tr>
                    <td>{{ $campaign->title }}</td>
                    <td>S/ {{ number_format($campaign->current_amount, 2) }} / {{ number_format($campaign->goal_amount, 2) }} ({{ $campaign->progress }}%)</td>
                    <td><span class="badge {{ $campaign->status === 'active' ? 'text-bg-success' : 'text-bg-secondary' }}">{{ \App\Models\Campaign::STATUSES[$campaign->status] }}</span></td>
                    <td class="text-end text-nowrap">
                        <form method="POST" action="{{ route('admin.campaigns.status', $campaign) }}" class="d-inline">
                            @csrf @method('PATCH')
                            <button class="btn btn-sm btn-outline-primary" type="submit">{{ $campaign->status === 'active' ? 'Marcar completada' : 'Reactivar' }}</button>
                        </form>
                        <a href="{{ route('admin.campaigns.edit', $campaign) }}" class="btn btn-sm btn-outline-secondary">Editar</a>
                        <form method="POST" action="{{ route('admin.campaigns.destroy', $campaign) }}" class="d-inline" onsubmit="return confirm('¿Eliminar esta campaña? No se puede deshacer.')">
                            @csrf @method('DELETE')
                            <button class="btn btn-sm btn-outline-danger" type="submit">Eliminar</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="4" class="text-secondary">Aún no hay campañas. Crea la primera.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    {{ $campaigns->links() }}
</div>
@endsection
