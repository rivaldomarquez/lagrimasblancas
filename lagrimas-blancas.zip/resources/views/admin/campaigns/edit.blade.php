@extends('layouts.app')
@section('title', 'Editar campaña')

@section('content')
<div class="container py-4" style="max-width: 760px">
    <h1 class="section-title">Editar campaña</h1>
    <form method="POST" action="{{ route('admin.campaigns.update', $campaign) }}">
        @csrf
        @method('PUT')
        @include('admin.campaigns._form')
        <button class="btn btn-cta" type="submit">Guardar cambios</button>
        <a href="{{ route('admin.campaigns.index') }}" class="btn btn-link">Cancelar</a>
    </form>
</div>
@endsection
