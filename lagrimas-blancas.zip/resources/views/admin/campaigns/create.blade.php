@extends('layouts.app')
@section('title', 'Nueva campaña')

@section('content')
<div class="container py-4" style="max-width: 760px">
    <h1 class="section-title">Nueva campaña</h1>
    <form method="POST" action="{{ route('admin.campaigns.store') }}">
        @csrf
        @include('admin.campaigns._form')
        <button class="btn btn-cta" type="submit">Crear campaña</button>
        <a href="{{ route('admin.campaigns.index') }}" class="btn btn-link">Cancelar</a>
    </form>
</div>
@endsection
