{{-- Formulario compartido (crear/editar). $campaign puede ser null --}}
@php $c = $campaign ?? null; @endphp
<div class="mb-3">
    <label for="title" class="form-label">Título</label>
    <input type="text" id="title" name="title" value="{{ old('title', $c?->title) }}" class="form-control @error('title') is-invalid @enderror" required maxlength="150">
    @error('title')<div class="invalid-feedback">{{ $message }}</div>@enderror
</div>
<div class="mb-3">
    <label for="description" class="form-label">Descripción</label>
    <textarea id="description" name="description" rows="5" class="form-control @error('description') is-invalid @enderror" required>{{ old('description', $c?->description) }}</textarea>
    @error('description')<div class="invalid-feedback">{{ $message }}</div>@enderror
</div>
<div class="row">
    <div class="col-md-4 mb-3">
        <label for="goal_amount" class="form-label">Meta (S/)</label>
        <input type="number" step="0.01" min="1" id="goal_amount" name="goal_amount" value="{{ old('goal_amount', $c?->goal_amount) }}" class="form-control @error('goal_amount') is-invalid @enderror" required>
        @error('goal_amount')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>
    <div class="col-md-4 mb-3">
        <label for="current_amount" class="form-label">Recaudado (S/)</label>
        <input type="number" step="0.01" min="0" id="current_amount" name="current_amount" value="{{ old('current_amount', $c?->current_amount ?? 0) }}" class="form-control @error('current_amount') is-invalid @enderror">
        @error('current_amount')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>
    <div class="col-md-4 mb-3">
        <label for="status" class="form-label">Estado</label>
        <select id="status" name="status" class="form-select @error('status') is-invalid @enderror" required>
            @foreach(\App\Models\Campaign::STATUSES as $key => $label)
                <option value="{{ $key }}" @selected(old('status', $c?->status ?? 'active') === $key)>{{ $label }}</option>
            @endforeach
        </select>
        @error('status')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>
</div>
<div class="mb-3">
    <label for="image_url" class="form-label">URL de imagen (opcional)</label>
    <input type="url" id="image_url" name="image_url" value="{{ old('image_url', $c?->image_url) }}" class="form-control @error('image_url') is-invalid @enderror" placeholder="https://...">
    @error('image_url')<div class="invalid-feedback">{{ $message }}</div>@enderror
</div>
