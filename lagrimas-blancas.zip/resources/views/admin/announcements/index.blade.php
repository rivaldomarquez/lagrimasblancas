@extends('layouts.app')
@section('title', 'Comunicados (admin)')

@section('content')
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1 class="section-title mb-0">Comunicados</h1>
        <a href="{{ route('admin.announcements.create') }}" class="btn btn-cta">Nuevo comunicado</a>
    </div>
    <div class="d-flex flex-wrap gap-2 mb-3">
        <a href="{{ route('admin.announcements.index') }}" class="btn btn-sm {{ $category ? 'btn-outline-primary' : 'btn-primary' }}">Todas</a>
        @foreach($categories as $cat)
            <a href="{{ route('admin.announcements.index', ['category' => $cat]) }}" class="btn btn-sm {{ $category === $cat ? 'btn-primary' : 'btn-outline-primary' }}">{{ $cat }}</a>
        @endforeach
    </div>
    <div class="table-responsive">
        <table class="table table-hover">
            <thead><tr><th>Título</th><th>Categoría</th><th>Publicado</th><th>Autor</th><th class="text-end">Acciones</th></tr></thead>
            <tbody>
            @forelse($announcements as $announcement)
                <tr>
                    <td>{{ $announcement->title }}</td>
                    <td><span class="badge badge-cat {{ $announcement->category === 'Urgente' ? 'urgent' : '' }}">{{ $announcement->category }}</span></td>
                    <td>{{ $announcement->published_at?->format('d/m/Y H:i') ?? 'Borrador' }}</td>
                    <td>{{ $announcement->author->name ?? '—' }}</td>
                    <td class="text-end text-nowrap">
                        <a href="{{ route('admin.announcements.edit', $announcement) }}" class="btn btn-sm btn-outline-secondary">Editar</a>
                        <form method="POST" action="{{ route('admin.announcements.destroy', $announcement) }}" class="d-inline" onsubmit="return confirm('¿Eliminar este comunicado?')">
                            @csrf @method('DELETE')
                            <button class="btn btn-sm btn-outline-danger" type="submit">Eliminar</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="5" class="text-secondary">No hay comunicados en esta categoría.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    {{ $announcements->links() }}
</div>
@endsection
