@extends('layouts.app')
@section('title', 'Editar comunicado')

@section('content')
<div class="container py-4" style="max-width: 760px">
    <h1 class="section-title">Editar comunicado</h1>
    <form method="POST" action="{{ route('admin.announcements.update', $announcement) }}">
        @csrf
        @method('PUT')
        @include('admin.announcements._form')
        <button class="btn btn-cta" type="submit">Guardar cambios</button>
        <a href="{{ route('admin.announcements.index') }}" class="btn btn-link">Cancelar</a>
    </form>
</div>
@endsection
