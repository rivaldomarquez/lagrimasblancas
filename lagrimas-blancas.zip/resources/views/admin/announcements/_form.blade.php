@php $a = $announcement ?? null; @endphp
<div class="mb-3">
    <label for="title" class="form-label">Título</label>
    <input type="text" id="title" name="title" value="{{ old('title', $a?->title) }}" class="form-control @error('title') is-invalid @enderror" required maxlength="150">
    @error('title')<div class="invalid-feedback">{{ $message }}</div>@enderror
</div>
<div class="row">
    <div class="col-md-6 mb-3">
        <label for="category" class="form-label">Categoría</label>
        <select id="category" name="category" class="form-select @error('category') is-invalid @enderror" required>
            @foreach($categories as $cat)
                <option value="{{ $cat }}" @selected(old('category', $a?->category) === $cat)>{{ $cat }}</option>
            @endforeach
        </select>
        @error('category')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>
    <div class="col-md-6 mb-3">
        <label for="published_at" class="form-label">Fecha de publicación (vacío = ahora)</label>
        <input type="datetime-local" id="published_at" name="published_at" value="{{ old('published_at', $a?->published_at?->format('Y-m-d\TH:i')) }}" class="form-control @error('published_at') is-invalid @enderror">
        @error('published_at')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>
</div>
<div class="mb-3">
    <label for="content" class="form-label">Contenido</label>
    <textarea id="content" name="content" rows="8" class="form-control @error('content') is-invalid @enderror" required>{{ old('content', $a?->content) }}</textarea>
    @error('content')<div class="invalid-feedback">{{ $message }}</div>@enderror
</div>
