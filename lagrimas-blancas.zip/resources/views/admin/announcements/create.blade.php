@extends('layouts.app')
@section('title', 'Nuevo comunicado')

@section('content')
<div class="container py-4" style="max-width: 760px">
    <h1 class="section-title">Nuevo comunicado</h1>
    <form method="POST" action="{{ route('admin.announcements.store') }}">
        @csrf
        @include('admin.announcements._form')
        <button class="btn btn-cta" type="submit">Publicar</button>
        <a href="{{ route('admin.announcements.index') }}" class="btn btn-link">Cancelar</a>
    </form>
</div>
@endsection
