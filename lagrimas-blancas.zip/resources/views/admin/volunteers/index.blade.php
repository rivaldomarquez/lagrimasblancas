@extends('layouts.app')
@section('title', 'Voluntarios (admin)')

@section('content')
<div class="container py-4">
    <h1 class="section-title">Solicitudes de voluntariado</h1>

    {{-- Filtros (GET, sin datos sensibles) --}}
    <form method="GET" action="{{ route('admin.volunteers.index') }}" class="row g-2 my-3">
        <div class="col-12 col-md-5">
            <input type="search" name="q" value="{{ $q }}" class="form-control" placeholder="Buscar por nombre o correo" aria-label="Buscar">
        </div>
        <div class="col-8 col-md-4">
            <select name="status" class="form-select" aria-label="Filtrar por estado">
                <option value="">Todos los estados</option>
                @foreach($statuses as $key => $label)
                    <option value="{{ $key }}" @selected($status === $key)>{{ $label }}</option>
                @endforeach
            </select>
        </div>
        <div class="col-4 col-md-3 d-grid"><button class="btn btn-primary" type="submit">Filtrar</button></div>
    </form>

    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead><tr><th>Voluntario</th><th>Contacto</th><th>Disponibilidad y habilidades</th><th>Estado</th><th></th></tr></thead>
            <tbody>
            @forelse($volunteers as $v)
                <tr>
                    <td>{{ $v->full_name }}<div class="small text-secondary">{{ $v->created_at->format('d/m/Y') }}</div></td>
                    <td class="small">{{ $v->email }}<br>{{ $v->phone }}</td>
                    <td class="small"><strong>{{ $v->availability }}</strong><br>{{ \Illuminate\Support\Str::limit($v->skills, 100) }}</td>
                    <td>
                        <form method="POST" action="{{ route('admin.volunteers.status', $v) }}" class="d-flex gap-1">
                            @csrf @method('PATCH')
                            <select name="status" class="form-select form-select-sm" aria-label="Estado de {{ $v->full_name }}">
                                @foreach($statuses as $key => $label)
                                    <option value="{{ $key }}" @selected($v->status === $key)>{{ $label }}</option>
                                @endforeach
                            </select>
                            <button class="btn btn-sm btn-primary" type="submit">Guardar</button>
                        </form>
                    </td>
                    <td class="text-end">
                        <form method="POST" action="{{ route('admin.volunteers.destroy', $v) }}" onsubmit="return confirm('¿Eliminar esta solicitud?')">
                            @csrf @method('DELETE')
                            <button class="btn btn-sm btn-outline-danger" type="submit">Eliminar</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="5" class="text-secondary">No hay solicitudes con estos filtros.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    {{ $volunteers->links() }}
</div>
@endsection
