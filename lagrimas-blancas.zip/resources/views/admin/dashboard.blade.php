@extends('layouts.app')
@section('title', 'Panel de administración')

@section('content')
<div class="container py-4">
    <h1 class="section-title">Panel de administración</h1>
    <div class="row g-4 my-2">
        <div class="col-6 col-lg-3"><div class="stat"><div class="num">{{ $activeCampaigns }}</div>campañas activas</div></div>
        <div class="col-6 col-lg-3"><div class="stat"><div class="num">S/ {{ number_format($totalRaised, 2) }}</div>recaudado</div></div>
        <div class="col-6 col-lg-3"><div class="stat"><div class="num">{{ $announcementsCount }}</div>comunicados</div></div>
        <div class="col-6 col-lg-3"><div class="stat"><div class="num">{{ $pendingVolunteers }}</div>postulaciones pendientes</div></div>
    </div>

    <h2 class="h4 mt-4">Últimas postulaciones</h2>
    <div class="table-responsive">
        <table class="table">
            <thead><tr><th>Nombre</th><th>Correo</th><th>Estado</th><th>Fecha</th></tr></thead>
            <tbody>
            @forelse($latestVolunteers as $v)
                <tr>
                    <td>{{ $v->full_name }}</td>
                    <td>{{ $v->email }}</td>
                    <td>{{ \App\Models\Volunteer::STATUSES[$v->status] }}</td>
                    <td>{{ $v->created_at->format('d/m/Y') }}</td>
                </tr>
            @empty
                <tr><td colspan="4" class="text-secondary">Aún no hay postulaciones.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    <a href="{{ route('admin.volunteers.index') }}" class="btn btn-outline-primary btn-sm">Gestionar voluntarios</a>
</div>
@endsection
