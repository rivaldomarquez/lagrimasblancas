<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    {{-- Token CSRF disponible también para peticiones JS --}}
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Lágrimas Blancas') · ONG Arequipa</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@500;600;700&family=Manrope:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="{{ asset('css/custom.css') }}" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100">

<nav class="navbar navbar-expand-lg sticky-top">
    <div class="container">
        <a class="brand" href="{{ route('home') }}"><span class="drop"></span> Lágrimas Blancas</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Abrir menú">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-1">
                <li class="nav-item"><a class="nav-link {{ request()->routeIs('campaigns.*') ? 'active' : '' }}" href="{{ route('campaigns.index') }}">Campañas</a></li>
                <li class="nav-item"><a class="nav-link {{ request()->routeIs('announcements.*') ? 'active' : '' }}" href="{{ route('announcements.index') }}">Noticias</a></li>
                <li class="nav-item"><a class="nav-link {{ request()->routeIs('volunteers.*') ? 'active' : '' }}" href="{{ route('volunteers.create') }}">Voluntariado</a></li>
                <li class="nav-item"><a class="nav-link {{ request()->routeIs('donations') ? 'active' : '' }}" href="{{ route('donations') }}">Transparencia</a></li>
                @auth
                    @if(auth()->user()->isAdmin())
                        <li class="nav-item"><a class="nav-link" href="{{ route('admin.dashboard') }}">Panel</a></li>
                    @endif
                    <li class="nav-item">
                        <form method="POST" action="{{ route('logout') }}" class="d-inline">
                            @csrf
                            <button class="btn btn-link nav-link" type="submit">Salir ({{ auth()->user()->name }})</button>
                        </form>
                    </li>
                @else
                    <li class="nav-item"><a class="nav-link" href="{{ route('login') }}">Ingresar</a></li>
                @endauth
                <li class="nav-item ms-lg-2"><a class="btn btn-cta" href="{{ route('donations') }}">Donar</a></li>
            </ul>
        </div>
    </div>
</nav>

@auth
    @if(auth()->user()->isAdmin() && request()->is('admin*'))
        <div class="admin-bar py-2">
            <div class="container d-flex flex-wrap">
                <a href="{{ route('admin.dashboard') }}">Resumen</a>
                <a href="{{ route('admin.campaigns.index') }}">Campañas</a>
                <a href="{{ route('admin.announcements.index') }}">Comunicados</a>
                <a href="{{ route('admin.volunteers.index') }}">Voluntarios</a>
            </div>
        </div>
    @endif
@endauth

<main class="flex-grow-1">
    <div class="container pt-3">
        @include('partials.flash')
    </div>
    @yield('content')
</main>

<footer class="py-4 mt-5">
    <div class="container d-flex flex-column flex-md-row justify-content-between gap-2 small">
        <span>© {{ date('Y') }} Lágrimas Blancas · {{ config('ngo.city') }}</span>
        <span>{{ config('ngo.email') }} · {{ config('ngo.phone') }}</span>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
