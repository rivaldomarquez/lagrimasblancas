@extends('layouts.app')
@section('title', 'Crear cuenta')

@section('content')
<div class="container py-4" style="max-width: 440px">
    <h1 class="section-title">Crear cuenta</h1>
    <form method="POST" action="{{ route('register') }}">
        @csrf
        <div class="mb-3">
            <label for="name" class="form-label">Nombre</label>
            <input type="text" id="name" name="name" value="{{ old('name') }}" class="form-control" required maxlength="100">
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Correo electrónico</label>
            <input type="email" id="email" name="email" value="{{ old('email') }}" class="form-control" required autocomplete="username">
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Contraseña (mín. 8, con letras y números)</label>
            <input type="password" id="password" name="password" class="form-control" required autocomplete="new-password">
        </div>
        <div class="mb-3">
            <label for="password_confirmation" class="form-label">Confirmar contraseña</label>
            <input type="password" id="password_confirmation" name="password_confirmation" class="form-control" required autocomplete="new-password">
        </div>
        <button class="btn btn-primary w-100" type="submit">Crear cuenta</button>
    </form>
</div>
@endsection
