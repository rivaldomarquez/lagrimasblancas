@extends('layouts.app')
@section('title', 'Ingresar')

@section('content')
<div class="container py-4" style="max-width: 440px">
    <h1 class="section-title">Ingresar</h1>
    <form method="POST" action="{{ route('login') }}">
        @csrf
        <div class="mb-3">
            <label for="email" class="form-label">Correo electrónico</label>
            <input type="email" id="email" name="email" value="{{ old('email') }}" class="form-control" required autofocus autocomplete="username">
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Contraseña</label>
            <input type="password" id="password" name="password" class="form-control" required autocomplete="current-password">
        </div>
        <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" name="remember" id="remember">
            <label class="form-check-label" for="remember">Recordarme</label>
        </div>
        <button class="btn btn-primary w-100" type="submit">Ingresar</button>
    </form>
    <p class="mt-3 small">¿No tienes cuenta? <a href="{{ route('register') }}">Regístrate</a></p>
</div>
@endsection
