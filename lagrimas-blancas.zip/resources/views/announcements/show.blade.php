@extends('layouts.app')
@section('title', $announcement->title)

@section('content')
<article class="container py-4" style="max-width: 760px">
    <a href="{{ route('announcements.index') }}" class="small">&larr; Todas las noticias</a>
    <div class="mt-3">
        <span class="badge badge-cat {{ $announcement->category === 'Urgente' ? 'urgent' : '' }}">{{ $announcement->category }}</span>
        <span class="small text-secondary ms-2">{{ $announcement->published_at->translatedFormat('d \d\e F, Y') }} · {{ $announcement->author->name ?? 'ONG' }}</span>
    </div>
    <h1 class="mt-2">{{ $announcement->title }}</h1>
    <p class="pre-wrap fs-5 mt-3">{{ $announcement->content }}</p>
</article>
@endsection
