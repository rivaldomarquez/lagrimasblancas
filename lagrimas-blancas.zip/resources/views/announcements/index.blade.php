@extends('layouts.app')
@section('title', 'Noticias')

@section('content')
<div class="container py-4">
    <h1 class="section-title">Noticias y comunicados</h1>
    <div class="d-flex flex-wrap gap-2 my-3">
        <a href="{{ route('announcements.index') }}" class="btn btn-sm {{ $category ? 'btn-outline-primary' : 'btn-primary' }}">Todas</a>
        @foreach($categories as $cat)
            <a href="{{ route('announcements.index', ['category' => $cat]) }}" class="btn btn-sm {{ $category === $cat ? 'btn-primary' : 'btn-outline-primary' }}">{{ $cat }}</a>
        @endforeach
    </div>
    <div class="row g-4">
        @forelse($announcements as $announcement)
            <div class="col-12 col-md-6 col-lg-4">@include('partials.announcement-card')</div>
        @empty
            <p class="text-secondary">No hay comunicados en esta categoría.</p>
        @endforelse
    </div>
    <div class="mt-4">{{ $announcements->links() }}</div>
</div>
@endsection
