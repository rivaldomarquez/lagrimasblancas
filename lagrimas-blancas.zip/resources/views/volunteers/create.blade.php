@extends('layouts.app')
@section('title', 'Voluntariado')

@section('content')
<div class="container py-4" style="max-width: 720px">
    <h1 class="section-title">Postula como voluntario</h1>
    <p class="text-secondary">Completa el formulario y nuestro equipo se pondrá en contacto contigo. No necesitas crear una cuenta.</p>

    <form method="POST" action="{{ route('volunteers.store') }}" novalidate>
        @csrf
        <div class="mb-3">
            <label for="full_name" class="form-label">Nombre completo</label>
            <input type="text" id="full_name" name="full_name" value="{{ old('full_name') }}" class="form-control @error('full_name') is-invalid @enderror" required maxlength="120">
            @error('full_name')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>
        <div class="row">
            <div class="col-md-7 mb-3">
                <label for="email" class="form-label">Correo electrónico</label>
                <input type="email" id="email" name="email" value="{{ old('email') }}" class="form-control @error('email') is-invalid @enderror" required maxlength="150">
                @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="col-md-5 mb-3">
                <label for="phone" class="form-label">Teléfono</label>
                <input type="tel" id="phone" name="phone" value="{{ old('phone') }}" class="form-control @error('phone') is-invalid @enderror" required maxlength="20">
                @error('phone')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
        </div>
        <div class="mb-3">
            <label for="availability" class="form-label">Disponibilidad</label>
            <input type="text" id="availability" name="availability" value="{{ old('availability') }}" placeholder="Ej: sábados por la mañana" class="form-control @error('availability') is-invalid @enderror" required maxlength="255">
            @error('availability')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>
        <div class="mb-3">
            <label for="skills" class="form-label">Habilidades y experiencia</label>
            <textarea id="skills" name="skills" rows="4" class="form-control @error('skills') is-invalid @enderror" required maxlength="2000">{{ old('skills') }}</textarea>
            @error('skills')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>
        <button type="submit" class="btn btn-cta btn-lg">Enviar postulación</button>
    </form>
</div>
@endsection
