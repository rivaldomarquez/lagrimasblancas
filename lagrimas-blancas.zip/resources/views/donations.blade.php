@extends('layouts.app')
@section('title', 'Transparencia y donaciones')

@section('content')
<div class="container py-4">
    <h1 class="section-title">Transparencia y donaciones</h1>
    <p class="text-secondary" style="max-width: 60ch">{{ $ngo['transparency'] }}</p>

    <div class="row g-4 mt-1">
        <div class="col-lg-7">
            <h2 class="h4">Cuentas bancarias</h2>
            @foreach($ngo['accounts'] as $acc)
                <div class="card-lb p-3 mb-3">
                    <strong>{{ $acc['bank'] }}</strong> <span class="text-secondary">· {{ $acc['type'] }}</span>
                    <div>N.º de cuenta: <code>{{ $acc['number'] }}</code></div>
                    <div>CCI: <code>{{ $acc['cci'] }}</code></div>
                </div>
            @endforeach
            <div class="card-lb p-3">
                <strong>Yape / Plin</strong>: <code>{{ $ngo['yape'] }}</code>
                <div class="small text-secondary">A nombre de {{ $ngo['name'] }}</div>
            </div>

            <h2 class="h4 mt-4">Cómo donar</h2>
            <ol class="ps-3">
                @foreach($ngo['steps'] as $step)<li class="mb-1">{{ $step }}</li>@endforeach
            </ol>
            <p class="small text-secondary">Envía tu comprobante a <a href="mailto:{{ $ngo['email'] }}">{{ $ngo['email'] }}</a>.</p>
        </div>
        <div class="col-lg-5 text-center">
            <h2 class="h4">Escanea el código QR</h2>
            <img src="{{ asset($ngo['qr']) }}" alt="Código QR para donar" class="img-fluid border rounded p-2" style="max-width: 280px">
        </div>
    </div>
</div>
@endsection
