<?php

/**
 * Información institucional. IMPORTANTE: reemplazar los datos de ejemplo
 * por las cuentas reales de la ONG antes de publicar.
 */
return [
    'name'    => 'Lágrimas Blancas',
    'city'    => 'Arequipa, Perú',
    'email'   => 'contacto@lagrimasblancas.org',
    'phone'   => '+51 054 000 000',
    'accounts' => [
        ['bank' => 'BCP',        'type' => 'Cuenta de ahorros (S/)', 'number' => '000-0000000-0-00',    'cci' => '002-000-000000000000-00'],
        ['bank' => 'Interbank',  'type' => 'Cuenta corriente (S/)',  'number' => '000-0000000000',      'cci' => '003-000-000000000000-00'],
    ],
    'yape'    => '999 999 999',
    'qr'      => 'images/qr-donaciones.svg',
    'steps'   => [
        'Elige la campaña a la que deseas aportar.',
        'Realiza la transferencia o escanea el código QR.',
        'Envía tu comprobante a nuestro correo indicando la campaña.',
        'Recibirás un recibo de donación y verás el avance en la página.',
    ],
    'transparency' => 'Publicamos el avance de cada campaña y rendimos cuentas de cada sol recibido.',
];
