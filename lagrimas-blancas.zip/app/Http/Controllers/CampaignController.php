<?php

namespace App\Http\Controllers;

use App\Models\Campaign;

/** Vista pública de campañas (solo lectura). */
class CampaignController extends Controller
{
    public function index()
    {
        // Eloquent => consultas preparadas (sin SQL Injection)
        $campaigns = Campaign::latest()->paginate(9);
        return view('campaigns.index', compact('campaigns'));
    }

    public function show(Campaign $campaign)
    {
        return view('campaigns.show', compact('campaign'));
    }
}
