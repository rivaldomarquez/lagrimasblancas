<?php

namespace App\Http\Controllers;

use App\Models\Announcement;
use Illuminate\Http\Request;

/** Vista pública de comunicados, filtrable por categoría. */
class AnnouncementController extends Controller
{
    public function index(Request $request)
    {
        $category = $request->query('category');

        $announcements = Announcement::published()
            ->category($category) // valida contra lista blanca
            ->with('author:id,name')
            ->latest('published_at')
            ->paginate(6)
            ->withQueryString();

        return view('announcements.index', [
            'announcements' => $announcements,
            'category'      => $category,
            'categories'    => Announcement::CATEGORIES,
        ]);
    }

    public function show(Announcement $announcement)
    {
        abort_unless($announcement->published_at && $announcement->published_at->isPast(), 404);
        return view('announcements.show', compact('announcement'));
    }
}
