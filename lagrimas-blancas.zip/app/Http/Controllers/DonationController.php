<?php

namespace App\Http\Controllers;

/** Módulo de transparencia / donaciones. Datos en config/ngo.php (fáciles de editar). */
class DonationController extends Controller
{
    public function index()
    {
        return view('donations', ['ngo' => config('ngo')]);
    }
}
