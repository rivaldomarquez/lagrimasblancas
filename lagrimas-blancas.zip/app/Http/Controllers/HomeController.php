<?php

namespace App\Http\Controllers;

use App\Models\Announcement;
use App\Models\Campaign;

class HomeController extends Controller
{
    public function index()
    {
        return view('home', [
            'campaigns'     => Campaign::active()->latest()->take(3)->get(),
            'announcements' => Announcement::published()->latest('published_at')->take(3)->get(),
        ]);
    }
}
