<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Volunteer;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class VolunteerController extends Controller
{
    public function index(Request $request)
    {
        $status = $request->query('status');
        $q = trim((string) $request->query('q'));

        $volunteers = Volunteer::query()
            ->when(array_key_exists($status, Volunteer::STATUSES), fn ($query) => $query->where('status', $status))
            // Búsqueda con parámetros enlazados (bindings), nunca concatenada
            ->when($q !== '', fn ($query) => $query->where(function ($w) use ($q) {
                $w->where('full_name', 'like', "%{$q}%")->orWhere('email', 'like', "%{$q}%");
            }))
            ->latest()
            ->paginate(10)
            ->withQueryString();

        return view('admin.volunteers.index', [
            'volunteers' => $volunteers,
            'statuses'   => Volunteer::STATUSES,
            'status'     => $status,
            'q'          => $q,
        ]);
    }

    public function updateStatus(Request $request, Volunteer $volunteer)
    {
        $data = $request->validate([
            'status' => ['required', Rule::in(array_keys(Volunteer::STATUSES))],
        ]);

        $volunteer->status = $data['status'];
        $volunteer->save();

        return back()->with('success', 'Estado actualizado.');
    }

    public function destroy(Volunteer $volunteer)
    {
        $volunteer->delete();

        return back()->with('success', 'Solicitud eliminada.');
    }
}
