<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\AnnouncementRequest;
use App\Models\Announcement;
use Illuminate\Http\Request;

class AnnouncementController extends Controller
{
    public function index(Request $request)
    {
        $announcements = Announcement::category($request->query('category'))
            ->with('author:id,name')
            ->latest()
            ->paginate(10)
            ->withQueryString();

        return view('admin.announcements.index', [
            'announcements' => $announcements,
            'categories'    => Announcement::CATEGORIES,
            'category'      => $request->query('category'),
        ]);
    }

    public function create()
    {
        return view('admin.announcements.create', ['categories' => Announcement::CATEGORIES]);
    }

    public function store(AnnouncementRequest $request)
    {
        $data = $request->validated();
        $data['published_at'] = $data['published_at'] ?? now();
        $data['user_id'] = $request->user()->id; // autor = admin autenticado

        Announcement::create($data);

        return redirect()->route('admin.announcements.index')->with('success', 'Comunicado publicado.');
    }

    public function edit(Announcement $announcement)
    {
        return view('admin.announcements.edit', [
            'announcement' => $announcement,
            'categories'   => Announcement::CATEGORIES,
        ]);
    }

    public function update(AnnouncementRequest $request, Announcement $announcement)
    {
        $data = $request->validated();
        $data['published_at'] = $data['published_at'] ?? $announcement->published_at ?? now();

        $announcement->update($data);

        return redirect()->route('admin.announcements.index')->with('success', 'Comunicado actualizado.');
    }

    public function destroy(Announcement $announcement)
    {
        $announcement->delete();

        return redirect()->route('admin.announcements.index')->with('success', 'Comunicado eliminado.');
    }
}
