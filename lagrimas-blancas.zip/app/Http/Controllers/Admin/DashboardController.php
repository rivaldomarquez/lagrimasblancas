<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Announcement;
use App\Models\Campaign;
use App\Models\Volunteer;

class DashboardController extends Controller
{
    public function index()
    {
        return view('admin.dashboard', [
            'activeCampaigns'   => Campaign::active()->count(),
            'totalRaised'       => Campaign::sum('current_amount'),
            'announcementsCount' => Announcement::count(),
            'pendingVolunteers' => Volunteer::where('status', 'pending')->count(),
            'latestVolunteers'  => Volunteer::latest()->take(5)->get(),
        ]);
    }
}
