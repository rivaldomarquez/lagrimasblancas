<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\CampaignRequest;
use App\Models\Campaign;

class CampaignController extends Controller
{
    public function index()
    {
        $campaigns = Campaign::latest()->paginate(10);
        return view('admin.campaigns.index', compact('campaigns'));
    }

    public function create()
    {
        return view('admin.campaigns.create');
    }

    public function store(CampaignRequest $request)
    {
        $data = $request->validated();
        $data['current_amount'] = $data['current_amount'] ?? 0;

        Campaign::create($data);

        return redirect()->route('admin.campaigns.index')->with('success', 'Campaña creada.');
    }

    public function edit(Campaign $campaign)
    {
        return view('admin.campaigns.edit', compact('campaign'));
    }

    public function update(CampaignRequest $request, Campaign $campaign)
    {
        $data = $request->validated();
        $data['current_amount'] = $data['current_amount'] ?? 0;

        $campaign->update($data);

        return redirect()->route('admin.campaigns.index')->with('success', 'Campaña actualizada.');
    }

    /** Alterna entre 'active' y 'completed' */
    public function toggleStatus(Campaign $campaign)
    {
        $campaign->update(['status' => $campaign->status === 'active' ? 'completed' : 'active']);

        return back()->with('success', 'Estado de la campaña actualizado.');
    }

    public function destroy(Campaign $campaign)
    {
        $campaign->delete();

        return redirect()->route('admin.campaigns.index')->with('success', 'Campaña eliminada.');
    }
}
