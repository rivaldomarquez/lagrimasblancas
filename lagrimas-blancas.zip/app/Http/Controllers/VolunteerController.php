<?php

namespace App\Http\Controllers;

use App\Http\Requests\VolunteerRequest;
use App\Models\Volunteer;

/** Postulación pública de voluntarios (no requiere login). */
class VolunteerController extends Controller
{
    public function create()
    {
        return view('volunteers.create');
    }

    public function store(VolunteerRequest $request)
    {
        // Solo campos validados; el estado inicial es 'pending' (default de BD)
        Volunteer::create($request->validated());

        return redirect()->route('volunteers.create')
            ->with('success', '¡Gracias! Recibimos tu postulación. Te contactaremos pronto.');
    }
}
