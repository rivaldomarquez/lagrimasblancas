<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

/** Formulario público de postulación (sin login). */
class VolunteerRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    protected function prepareForValidation(): void
    {
        $this->merge(array_map(
            fn ($v) => is_string($v) ? trim(strip_tags($v)) : $v,
            $this->only(['full_name', 'email', 'phone', 'availability', 'skills'])
        ));
    }

    public function rules(): array
    {
        return [
            'full_name'    => ['required', 'string', 'min:3', 'max:120'],
            'email'        => ['required', 'email:rfc', 'max:150', 'unique:volunteers,email'],
            'phone'        => ['required', 'regex:/^[0-9+\s()\-]{7,20}$/'],
            'availability' => ['required', 'string', 'max:255'],
            'skills'       => ['required', 'string', 'min:10', 'max:2000'],
        ];
    }

    public function messages(): array
    {
        return [
            'full_name.required'  => 'Ingresa tu nombre completo.',
            'email.unique'        => 'Este correo ya registró una postulación.',
            'phone.regex'         => 'El teléfono solo admite números, +, espacios y paréntesis (7 a 20 caracteres).',
            'availability.required' => 'Cuéntanos tu disponibilidad.',
            'skills.min'          => 'Describe tus habilidades con al menos 10 caracteres.',
        ];
    }
}
