<?php

namespace App\Http\Requests;

use App\Models\Announcement;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class AnnouncementRequest extends FormRequest
{
    public function authorize(): bool
    {
        return (bool) $this->user()?->isAdmin();
    }

    protected function prepareForValidation(): void
    {
        $this->merge(array_map(
            fn ($v) => is_string($v) ? trim(strip_tags($v)) : $v,
            $this->only(['title', 'content'])
        ));
    }

    public function rules(): array
    {
        return [
            'title'        => ['required', 'string', 'min:5', 'max:150'],
            'content'      => ['required', 'string', 'min:20', 'max:10000'],
            'category'     => ['required', Rule::in(Announcement::CATEGORIES)],
            'published_at' => ['nullable', 'date'],
        ];
    }

    public function messages(): array
    {
        return [
            'title.required'   => 'El título es obligatorio.',
            'content.required' => 'El contenido es obligatorio.',
            'category.in'      => 'Selecciona una categoría válida.',
            'published_at.date' => 'La fecha de publicación no es válida.',
        ];
    }
}
