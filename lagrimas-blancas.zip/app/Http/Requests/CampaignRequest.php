<?php

namespace App\Http\Requests;

use App\Models\Campaign;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class CampaignRequest extends FormRequest
{
    public function authorize(): bool
    {
        return (bool) $this->user()?->isAdmin();
    }

    /** Sanitización: elimina etiquetas HTML de los campos de texto (anti-XSS almacenado) */
    protected function prepareForValidation(): void
    {
        $this->merge(array_map(
            fn ($v) => is_string($v) ? trim(strip_tags($v)) : $v,
            $this->only(['title', 'description', 'image_url'])
        ));
    }

    public function rules(): array
    {
        return [
            'title'          => ['required', 'string', 'min:5', 'max:150'],
            'description'    => ['required', 'string', 'min:20', 'max:5000'],
            'goal_amount'    => ['required', 'numeric', 'min:1', 'max:9999999999'],
            'current_amount' => ['nullable', 'numeric', 'min:0', 'max:9999999999'],
            'image_url'      => ['nullable', 'url:http,https', 'max:255'],
            'status'         => ['required', Rule::in(array_keys(Campaign::STATUSES))],
        ];
    }

    public function messages(): array
    {
        return [
            'title.required'       => 'El título es obligatorio.',
            'description.required' => 'La descripción es obligatoria.',
            'goal_amount.required' => 'Indica la meta de recaudación.',
            'goal_amount.numeric'  => 'La meta debe ser un número.',
            'image_url.url'        => 'La imagen debe ser una URL http(s) válida.',
        ];
    }
}
