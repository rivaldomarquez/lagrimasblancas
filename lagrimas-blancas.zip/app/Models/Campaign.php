<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Campaign extends Model
{
    public const STATUSES = ['active' => 'Activa', 'completed' => 'Completada'];

    protected $fillable = ['title', 'description', 'goal_amount', 'current_amount', 'image_url', 'status'];

    protected function casts(): array
    {
        return ['goal_amount' => 'decimal:2', 'current_amount' => 'decimal:2'];
    }

    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    /** Porcentaje de avance (0-100) */
    public function getProgressAttribute(): int
    {
        if ($this->goal_amount <= 0) {
            return 0;
        }
        return (int) min(100, round(($this->current_amount / $this->goal_amount) * 100));
    }
}
