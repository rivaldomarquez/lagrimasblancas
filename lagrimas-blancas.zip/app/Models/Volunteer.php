<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Volunteer extends Model
{
    public const STATUSES = ['pending' => 'Pendiente', 'approved' => 'Aprobado', 'rejected' => 'Rechazado'];

    // 'status' no es asignable en masa: solo el admin lo cambia explícitamente
    protected $fillable = ['full_name', 'email', 'phone', 'availability', 'skills'];
}
