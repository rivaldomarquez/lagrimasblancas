# Lágrimas Blancas — Aplicación Web (Laravel 11)

Este paquete contiene SOLO los archivos de la aplicación (overlay). Se copian sobre un proyecto Laravel 11 limpio.

## Instalación
```bash
composer create-project laravel/laravel lagrimas-blancas "^11.0"
cd lagrimas-blancas
# Copia el contenido de este ZIP encima (acepta sobrescribir bootstrap/app.php y app/Models/User.php)
```
Edita `.env`:
```
APP_NAME="Lágrimas Blancas"
APP_LOCALE=es
APP_TIMEZONE=America/Lima
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_DATABASE=lagrimas_blancas
DB_USERNAME=root
DB_PASSWORD=
BCRYPT_ROUNDS=12
SESSION_DRIVER=file
```
Crea la base de datos y ejecuta:
```bash
php artisan key:generate
php artisan migrate --seed
php artisan serve
```
Acceso admin: `admin@lagrimasblancas.org` / `Admin12345!` → **cambiar en producción**.

## Producción
- `APP_ENV=production`, `APP_DEBUG=false`, HTTPS activo y `SESSION_SECURE_COOKIE=true`.
- `php artisan config:cache route:cache view:cache`
- Reemplazar `public/images/qr-donaciones.svg` por el QR real y editar `config/ngo.php`.
